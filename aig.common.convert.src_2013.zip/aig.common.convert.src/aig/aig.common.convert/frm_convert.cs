﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using PQScan.PDFToImage;

namespace aig.common.convert
{
    public partial class frm_convert : Form
    {
        private string strMessage;

        public frm_convert()
        {
            InitializeComponent();
        }

        private void frm_convert_Load(object sender, EventArgs e)
        {
            long lngRes;
            lngRes = ConvertPDFtoTIFF("input", "output");

            if (lngRes == 1)
            {
                this.Close();
            }
            else
            {
                txt_message.Text = this.strMessage;
            }        
        }
        
        private long ConvertPDFtoTIFF(string strSourcePdfFile, string strTargetTiffFile)
        {
            try
            {
                // Create an instance of PQScan.PDFToImage.PDFDocument object.
                PDFDocument pdfDoc = new PDFDocument();

                // Load a local PDF file.
                pdfDoc.LoadPDF(strSourcePdfFile + ".pdf");

                // Obtain the total page count.
                int count = pdfDoc.PageCount;

                for (int i = 0; i < count; i++)
                {
                    // Turn PDF file page to image.
                    Bitmap tifImage = pdfDoc.ToImage(i);

                    // Save image as tiff image file type.
                    tifImage.Save(strTargetTiffFile + i + ".tiff", ImageFormat.Tiff);
                }
                return 1;
            }
            catch (Exception ex)
            {
                this.strMessage = ex.Message;
                return 0;
            }
        }
    }
}
