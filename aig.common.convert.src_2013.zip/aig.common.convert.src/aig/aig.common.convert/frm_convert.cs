﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using PQScan.PDFToImage;

namespace aig.common.convert
{
    public partial class frm_convert : Form
    {
        private string strMessage;

        public frm_convert()
        {
            InitializeComponent();
        }

        private void frm_convert_Load(object sender, EventArgs e)
        {
            long lngRes;
            lngRes = ConvertPDFtoTIFF("input", "output");
            //lngRes = ConvertPDFtoTIFF_ONE("input", "output");

            if (lngRes == 1)
            {
                this.Close();
            }
            else
            {
                txt_message.Text = this.strMessage;
            }        
        }
        
        private long ConvertPDFtoTIFF(string strSourcePdfFile, string strTargetTiffFile)
        {
            try
            {
                // Create an instance of PQScan.PDFToImage.PDFDocument object.
                PDFDocument pdfDoc = new PDFDocument();

                // Load a local PDF file.
                pdfDoc.LoadPDF(strSourcePdfFile + ".pdf");

                // Set output tif image width.
                int width = pdfDoc.GetPageWidth(0);

                // Set output tif image height.
                int height = pdfDoc.GetPageHeight(0);

                // Obtain the total page count.
                int count = pdfDoc.PageCount;
                //count = 3;

                // Turn PDF file page to image.
                Bitmap bitTemp = null;
                Bitmap tifImage = new Bitmap(width, height * count);

                for (int i = 0; i < count; i++)
                {
                    bitTemp = pdfDoc.ToImage(i);

                    using (Graphics grc = Graphics.FromImage(tifImage))
                    {
                        grc.DrawImage(bitTemp, 0, height * i);
                    }
                }

                tifImage.Save(strTargetTiffFile + ".tiff", ImageFormat.Tiff);

                return 1;
            }
            catch (Exception ex)
            {
                this.strMessage = ex.Message;
                return 0;
            }
        }

        private long ConvertPDFtoTIFF_ONE(string strSourcePdfFile, string strTargetTiffFile)
        {
            try
            {
                // Make a new instance of PQScan.PDFToImage.PDFDocument object.
                PDFDocument pdfDoc = new PDFDocument();

                // Create a file stream with PDF message.
                FileStream stream = new FileStream(strSourcePdfFile + ".pdf", FileMode.Open);

                // Load PDF from file stream.
                pdfDoc.LoadPDF(stream);

                // Set output tif image width.
                int width = pdfDoc.GetPageWidth(0) / 2;

                // Set output tif image height.
                int height = pdfDoc.GetPageHeight(0) / 2;

                // Convert the first PDF page to image with the desired size.
                Bitmap tif = pdfDoc.ToImage(0, width, height);

                // Save image to tif format.
                tif.Save(strTargetTiffFile + ".tiff", ImageFormat.Tiff);

                return 1;
            }
            catch (Exception ex)
            {
                return 0;
            }

        }

    }
}
