﻿using System;
using System.IO;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Xps.Packaging;
using System.Windows.Documents;
using System.Drawing;
using System.Drawing.Imaging;

namespace aig.org.cwf.convert
{
    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            if (args.Length < 1) { return; }

            XpsToImgSetting setting;
            try {
                setting = XpsToImgSetting.Create(args);
                if (setting.Result == false) { return; }
            }
            catch (ArgumentException ex) { Console.WriteLine(ex.Message); return; }

            XpsDocument doc;
            try
            {
                doc = new XpsDocument(setting.XpsPath, FileAccess.Read);
            } catch (ArgumentException ex) { return; }

            DocumentPaginator paginator = null;
            paginator = doc.GetFixedDocumentSequence().DocumentPaginator;
            
            // Set output tif image width.
            int width = (int)(paginator.GetPage(0).Size.Width * setting.Scale);
            // Set output tif image height.
            int height = (int)(paginator.GetPage(0).Size.Height * setting.Scale);
            // Obtain the total page count.
            int count = paginator.PageCount;

            Bitmap dstBit = new Bitmap(width, height * count, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
            Rectangle dstRect = new Rectangle();

            try
            {
                for (int i = 0; i < paginator.PageCount; i++)
                {
                    DocumentPage page = paginator.GetPage(i);
                    RenderTargetBitmap bmp = new RenderTargetBitmap((int)((page.Size.Width + 1) * setting.Scale),
                                                                    (int)((page.Size.Height + 1) * setting.Scale),
                                                                    96 * setting.Scale, 96 * setting.Scale,
                                                                    PixelFormats.Pbgra32);
                    bmp.Render(page.Visual);
                    PngBitmapEncoder encoder = new PngBitmapEncoder();
                    encoder.Frames.Add(BitmapFrame.Create(bmp));
                    MemoryStream stream = new MemoryStream();
                    encoder.Save(stream);
                    Bitmap tmpBit = new Bitmap(stream);

                    using (Graphics grc = Graphics.FromImage(dstBit))
                    {
                        dstRect.Width = tmpBit.Width;
                        dstRect.Height = tmpBit.Height;
                        grc.DrawImage(tmpBit, dstRect, 0, 0, tmpBit.Width, tmpBit.Height, GraphicsUnit.Pixel);
                        dstRect.Y = dstRect.Bottom;
                    }
                }

                string outpath = String.Format(@"{0}\{1}", setting.OutputFolder, setting.PrefixFile);
                dstBit.Save(outpath, ImageFormat.Tiff);

            }
            catch (ArgumentException ex) {
                Console.WriteLine(ex.Message);
                return;
            }

            Environment.Exit(0);
        }

        /// <summary>
        /// XpsToImgのコマンド引数
        /// </summary>
        internal sealed class XpsToImgSetting
        {
            public string XpsPath { get; set; }
            public string OutputFolder { get; set; }
            public string PrefixFile { get; set; }
            public double Scale { get; set; }
            public bool Result { get; set; }

            private XpsToImgSetting()
            {
            }
            /// <summary>
            /// コマンドライン引数を解析してXpsToImgSettingを作成する
            /// </summary>
            /// <param name="args"></param>
            /// <returns></returns>
            /// <exception cref="ArgumentException">コマンドラインの値が不正</exception>
            public static XpsToImgSetting Create(string[] args)
            {
                XpsToImgSetting obj = new XpsToImgSetting();

                try
                {
                    // output folder path (current folder)
                    obj.OutputFolder = Directory.GetCurrentDirectory();
                    // target xps file path
                    obj.XpsPath = obj.OutputFolder + @"\" + args[0];
                    if (Path.GetExtension(obj.XpsPath).ToUpper() != ".XPS") { obj.Result = false; return obj; }
                    if (File.Exists(obj.XpsPath) == false) { obj.Result = false; return obj; }
                    // target tif file name
                    obj.PrefixFile = Path.GetFileNameWithoutExtension(args[0]) + ".tif";

                    // Minimum magnification. 1 time dpi:96
                    obj.Scale = 1;
                    if (args.Length >= 2)
                    {   
                        double scale;
                        if (double.TryParse(args[1], out scale) == true) {
                            obj.Scale = (double)int.Parse(args[1]); }
                    }

                   obj.Result = true;
                }
                catch (FormatException ex){
                    Console.WriteLine(ex.Message); }
              
                return obj;
            }
        }
    }
}