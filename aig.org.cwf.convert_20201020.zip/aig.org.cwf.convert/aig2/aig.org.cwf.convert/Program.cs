﻿using System;
using System.IO;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Xps.Packaging;
using System.Windows.Documents;
using System.Globalization;
using System.Drawing;
using System.Drawing.Imaging;

namespace aig.org.cwf.convert
{
    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            string xpsPath;
            try
            {
                xpsPath = args[0];
                if (Path.GetExtension(xpsPath) != ".xps") { return; }
                if (File.Exists(xpsPath) ==false) { return; }
            } catch (ArgumentException ex) { return; }

            //Console.WriteLine(@"XpsFilePath : 変換対象のXpsファイル ex:c:\test.xps");      -- 第１パラメータ 
            //Console.WriteLine(@"OutputFolder : 出力先フォルダ ex:c:\tif");                 -- 第２パラメータ 
            //Console.WriteLine(@"PrefixFileName : 出力するファイルの接頭文字 ex:test");     -- 第３パラメータ
            //Console.WriteLine(@"dpi: 画像データの精度 ex:96");                             -- 第４パラメータ
            args = new string[4];
            args[0] = xpsPath;
            args[1] = Path.GetDirectoryName(xpsPath);
            args[2] = Path.GetFileNameWithoutExtension(xpsPath) + ".tif";
            args[3] = @"96";

            XpsToImgSetting setting;
            try
            {
                setting = XpsToImgSetting.Create(args);
                if (setting == null) { return; }
            } catch (ArgumentException ex) { return; }

            XpsDocument doc;
            try
            {
                doc = new XpsDocument(setting.XpsPath, FileAccess.Read);
            } catch (ArgumentException ex) { return; }

            DocumentPaginator paginator = null;
            paginator = doc.GetFixedDocumentSequence().DocumentPaginator;
            double scale = setting.Dpi / 96;
            
            // Set output tif image width.
            int width = (int)paginator.GetPage(0).Size.Width;
            // Set output tif image height.
            int height = (int)paginator.GetPage(0).Size.Height;
            // Obtain the total page count.
            int count = paginator.PageCount;

            Bitmap dstBit = new Bitmap(width, height* count, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
            Rectangle dstRect = new Rectangle();

            try
            {
                for (int i = 0; i < paginator.PageCount; i++)
                {
                    // 
                    DocumentPage page = paginator.GetPage(i);
                    RenderTargetBitmap bmp = new RenderTargetBitmap((int)((page.Size.Width + 1) * scale),
                                                                    (int)((page.Size.Height + 1) * scale),
                                                                    scale * 96, scale * 96,
                                                                    PixelFormats.Pbgra32);
                    bmp.Render(page.Visual);
                    PngBitmapEncoder encoder = new PngBitmapEncoder();
                    encoder.Frames.Add(BitmapFrame.Create(bmp));
                    MemoryStream stream = new MemoryStream();
                    encoder.Save(stream);
                    Bitmap tmpBit = new Bitmap(stream);

                    // 
                    using (Graphics grc = Graphics.FromImage(dstBit))
                    {
                        dstRect.Width = tmpBit.Width;
                        dstRect.Height = tmpBit.Height;
                        grc.DrawImage(tmpBit, dstRect, 0, 0, tmpBit.Width, tmpBit.Height, GraphicsUnit.Pixel);
                        dstRect.Y = dstRect.Bottom;
                    }
                }
                
                string outpath = String.Format(@"{0}\{1}", setting.OutputFolder, setting.PrefixFile);
                dstBit.Save(outpath, ImageFormat.Tiff);

            }
            catch (ArgumentException ex) { return; }

            Environment.Exit(0);
        }
    }

    /// <summary>
    /// XpsToImgのコマンド引数
    /// </summary>
    internal sealed class XpsToImgSetting
    {
        public string XpsPath { get; set; }
        public string OutputFolder { get; set; }
        public string PrefixFile { get; set; }
        public int Dpi { get; set; }
        private XpsToImgSetting()
        {
        }
        /// <summary>
        /// コマンドライン引数を解析してXpsToImgSettingを作成する
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentException">コマンドラインの値が不正</exception>
        public static XpsToImgSetting Create(string[] args)
        {
            XpsToImgSetting obj = new XpsToImgSetting();
            obj.XpsPath = args[0];
            obj.OutputFolder = args[1];
            obj.PrefixFile = args[2];
            try
            {
                obj.Dpi = Int32.Parse(args[3], CultureInfo.CurrentCulture);
                if (obj.Dpi < 96)
                {
                    throw new FormatException();
                }
            }
            catch (FormatException)
            {
                //throw new ArgumentException("dpi は96以上の整数を入力してください。");
            }
            // 
            if (!Directory.Exists(obj.OutputFolder))
            {
                // 出力先フォルダが存在しない場合は作成する
                try
                {
                    Directory.CreateDirectory(obj.OutputFolder);
                }
                catch (Exception ex)
                {
                    //throw new ArgumentException("出力フォルダが作成できません\n" + ex.Message); 
                }
            }
            return obj;
        }
    }
}